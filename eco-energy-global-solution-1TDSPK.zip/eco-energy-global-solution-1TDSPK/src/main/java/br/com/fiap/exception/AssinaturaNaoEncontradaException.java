package br.com.fiap.exception;

public class AssinaturaNaoEncontradaException extends ApplicationException {

    public AssinaturaNaoEncontradaException(String message) {
        super(message);
    }
}