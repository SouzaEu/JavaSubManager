package br.com.fiap.exception;

public class UsuarioNaoEncontradoException extends ApplicationException {

    public UsuarioNaoEncontradoException(String message) {
        super(message);
    }
}